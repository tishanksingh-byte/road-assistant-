document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("requestForm");
  if (form && window.L) {
    const map = L.map("requestMap").setView([26.9124, 75.7873], 11); // default view only; not user's location
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    let marker = null;
    const latInput = document.getElementById("latitude");
    const lngInput = document.getElementById("longitude");
    const coords = document.getElementById("coords");
    const status = document.getElementById("locationStatus");
    function setPoint(lat, lng, zoom = 15) {
      latInput.value = Number(lat).toFixed(7);
      lngInput.value = Number(lng).toFixed(7);
      if (marker) marker.setLatLng([lat, lng]);
      else marker = L.marker([lat, lng], { draggable: true }).addTo(map);
      marker.on("dragend", () => {
        const p = marker.getLatLng();
        setPoint(p.lat, p.lng, map.getZoom());
      });
      map.setView([lat, lng], zoom);
      coords.textContent = `Selected: ${Number(lat).toFixed(5)}, ${Number(lng).toFixed(5)}`;
      status.textContent = "Location selected. Submit the form to share it with ORVBA.";
    }
    map.on("click", e => setPoint(e.latlng.lat, e.latlng.lng));
    document.getElementById("locateBtn").addEventListener("click", () => {
      if (!navigator.geolocation) { status.textContent = "Geolocation is not supported by this browser."; return; }
      status.textContent = "Requesting your location permission…";
      navigator.geolocation.getCurrentPosition(
        p => setPoint(p.coords.latitude, p.coords.longitude),
        () => { status.textContent = "Could not get location. Allow permission or click the map."; },
        { enableHighAccuracy: true, timeout: 12000 }
      );
    });
    form.addEventListener("submit", e => {
      if (!latInput.value || !lngInput.value) {
        e.preventDefault();
        status.textContent = "Please select a location on the map first.";
        status.classList.add("error-text");
      }
    });
    setTimeout(() => map.invalidateSize(), 100);
  }

  const mechanicBtn = document.getElementById("mechanicLocateBtn");
  if (mechanicBtn) {
    mechanicBtn.addEventListener("click", () => {
      const status = document.getElementById("mechanicLocationStatus");
      if (!navigator.geolocation) { status.textContent = "Geolocation is not supported by this browser."; return; }
      status.textContent = "Requesting location permission…";
      navigator.geolocation.getCurrentPosition(p => {
        document.getElementById("mLat").value = p.coords.latitude.toFixed(7);
        document.getElementById("mLng").value = p.coords.longitude.toFixed(7);
        status.textContent = "Coordinates added. Save your profile to publish them.";
      }, () => { status.textContent = "Location unavailable. You can enter coordinates manually."; },
      { enableHighAccuracy: true, timeout: 12000 });
    });
  }
});

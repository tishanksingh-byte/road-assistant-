CREATE DATABASE IF NOT EXISTS orvba CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE orvba;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(25) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','mechanic','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mechanics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  workshop_name VARCHAR(150) NOT NULL,
  skills VARCHAR(255) DEFAULT 'General repair',
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  available BOOLEAN NOT NULL DEFAULT TRUE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS breakdown_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  vehicle_type VARCHAR(60) NOT NULL,
  issue_type VARCHAR(100) NOT NULL,
  description TEXT,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  address VARCHAR(255) DEFAULT '',
  status ENUM('Pending','Accepted','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  mechanic_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (mechanic_id) REFERENCES mechanics(id) ON DELETE SET NULL,
  INDEX idx_request_status(status),
  INDEX idx_request_user(user_id)
);

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  request_id INT NULL,
  rating TINYINT NOT NULL,
  comments VARCHAR(1000),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (request_id) REFERENCES breakdown_requests(id) ON DELETE SET NULL
);

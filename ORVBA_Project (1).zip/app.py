import os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-only-change-this-secret")
app.config["MYSQL_HOST"] = os.getenv("DB_HOST", "localhost")
app.config["MYSQL_USER"] = os.getenv("DB_USER", "root")
app.config["MYSQL_PASSWORD"] = os.getenv("DB_PASSWORD", "")
app.config["MYSQL_DB"] = os.getenv("DB_NAME", "orvba")
app.config["MYSQL_CURSORCLASS"] = "DictCursor"
mysql = MySQL(app)
bcrypt = Bcrypt(app)

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def role_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You do not have permission to view that page.", "danger")
                return redirect(url_for("dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return decorator

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        if not all([name, email, phone, password]):
            flash("Please complete all fields.", "danger")
            return render_template("register.html")
        if len(password) < 8:
            flash("Password must be at least 8 characters.", "danger")
            return render_template("register.html")
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO users(name,email,phone,password_hash) VALUES(%s,%s,%s,%s)",
                        (name, email, phone, bcrypt.generate_password_hash(password).decode("utf-8")))
            mysql.connection.commit()
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        except Exception:
            mysql.connection.rollback()
            flash("That email may already be registered. Please try another.", "danger")
        finally:
            cur.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        cur = mysql.connection.cursor()
        cur.execute("SELECT id,name,email,password_hash,role FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close()
        if user and bcrypt.check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["email"] = user["email"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    role = session["role"]
    cur = mysql.connection.cursor()
    if role == "admin":
        cur.execute("""SELECT r.*, u.name AS customer_name, u.phone AS customer_phone
                       FROM breakdown_requests r JOIN users u ON r.user_id=u.id
                       ORDER BY r.created_at DESC""")
        requests_list = cur.fetchall()
        cur.execute("SELECT COUNT(*) AS total FROM users")
        users_count = cur.fetchone()["total"]
        cur.execute("SELECT COUNT(*) AS total FROM breakdown_requests")
        requests_count = cur.fetchone()["total"]
        cur.close()
        return render_template("admin_dashboard.html", requests_list=requests_list,
                               users_count=users_count, requests_count=requests_count)
    if role == "mechanic":
        cur.execute("""SELECT m.id AS mechanic_id FROM mechanics m WHERE m.user_id=%s""", (session["user_id"],))
        mechanic = cur.fetchone()
        if mechanic:
            cur.execute("""SELECT r.*, u.name AS customer_name, u.phone AS customer_phone
                           FROM breakdown_requests r JOIN users u ON r.user_id=u.id
                           WHERE r.mechanic_id=%s ORDER BY r.created_at DESC""", (mechanic["mechanic_id"],))
            requests_list = cur.fetchall()
        else:
            requests_list = []
        cur.close()
        return render_template("mechanic_dashboard.html", requests_list=requests_list, has_profile=bool(mechanic))
    cur.execute("""SELECT * FROM breakdown_requests WHERE user_id=%s ORDER BY created_at DESC""",
                (session["user_id"],))
    requests_list = cur.fetchall()
    cur.close()
    return render_template("user_dashboard.html", requests_list=requests_list)

@app.route("/request-help", methods=["GET", "POST"])
@login_required
@role_required("user")
def request_help():
    if request.method == "POST":
        try:
            vehicle_type = request.form["vehicle_type"]
            issue_type = request.form["issue_type"]
            description = request.form.get("description", "").strip()
            lat = float(request.form["latitude"])
            lng = float(request.form["longitude"])
            address = request.form.get("address", "").strip()[:255]
            if not (-90 <= lat <= 90 and -180 <= lng <= 180):
                raise ValueError()
        except (KeyError, ValueError):
            flash("Choose a valid location on the map or use your current location.", "danger")
            return render_template("request_help.html")
        cur = mysql.connection.cursor()
        cur.execute("""INSERT INTO breakdown_requests
          (user_id,vehicle_type,issue_type,description,latitude,longitude,address)
          VALUES(%s,%s,%s,%s,%s,%s,%s)""",
          (session["user_id"], vehicle_type, issue_type, description, lat, lng, address))
        mysql.connection.commit()
        cur.close()
        flash("Breakdown request submitted. Keep your phone available.", "success")
        return redirect(url_for("dashboard"))
    return render_template("request_help.html")

@app.route("/mechanic/register", methods=["GET", "POST"])
@login_required
@role_required("mechanic")
def mechanic_register():
    cur = mysql.connection.cursor()
    if request.method == "POST":
        try:
            workshop = request.form["workshop_name"].strip()
            skills = request.form.get("skills", "General repair").strip()
            lat = float(request.form["latitude"]) if request.form.get("latitude") else None
            lng = float(request.form["longitude"]) if request.form.get("longitude") else None
            cur.execute("""INSERT INTO mechanics(user_id,workshop_name,skills,latitude,longitude)
              VALUES(%s,%s,%s,%s,%s)
              ON DUPLICATE KEY UPDATE workshop_name=VALUES(workshop_name),skills=VALUES(skills),
              latitude=VALUES(latitude),longitude=VALUES(longitude)""",
              (session["user_id"], workshop, skills, lat, lng))
            mysql.connection.commit()
            flash("Mechanic profile saved.", "success")
            return redirect(url_for("dashboard"))
        except (KeyError, ValueError):
            mysql.connection.rollback()
            flash("Please check the profile fields and coordinates.", "danger")
    cur.execute("SELECT * FROM mechanics WHERE user_id=%s", (session["user_id"],))
    profile = cur.fetchone()
    cur.close()
    return render_template("mechanic_register.html", profile=profile)

@app.route("/mechanics")
@login_required
def mechanics():
    cur = mysql.connection.cursor()
    cur.execute("""SELECT m.*, u.name, u.phone FROM mechanics m JOIN users u ON m.user_id=u.id
                   WHERE m.available=TRUE""")
    rows = cur.fetchall()
    cur.close()
    return render_template("mechanics.html", mechanics=rows)

@app.route("/admin/request/<int:request_id>/status", methods=["POST"])
@login_required
@role_required("admin")
def update_status(request_id):
    status = request.form.get("status")
    allowed = {"Pending", "Accepted", "In Progress", "Completed", "Cancelled"}
    if status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("dashboard"))
    cur = mysql.connection.cursor()
    cur.execute("UPDATE breakdown_requests SET status=%s WHERE id=%s", (status, request_id))
    mysql.connection.commit()
    cur.close()
    flash("Request status updated.", "success")
    return redirect(url_for("dashboard"))

@app.route("/feedback", methods=["POST"])
@login_required
def feedback():
    try:
        rating = int(request.form["rating"])
        comments = request.form.get("comments", "").strip()
        request_id = request.form.get("request_id") or None
        if rating < 1 or rating > 5:
            raise ValueError()
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO feedback(user_id,request_id,rating,comments) VALUES(%s,%s,%s,%s)",
                    (session["user_id"], request_id, rating, comments))
        mysql.connection.commit()
        cur.close()
        flash("Thank you for your feedback.", "success")
    except (KeyError, ValueError):
        flash("Please submit a rating from 1 to 5.", "danger")
    return redirect(url_for("dashboard"))

@app.route("/api/mechanics")
def api_mechanics():
    cur = mysql.connection.cursor()
    cur.execute("""SELECT m.id,m.workshop_name,m.skills,m.latitude,m.longitude,u.phone
                   FROM mechanics m JOIN users u ON u.id=m.user_id
                   WHERE m.available=TRUE AND m.latitude IS NOT NULL AND m.longitude IS NOT NULL""")
    data = cur.fetchall()
    cur.close()
    return jsonify(data)

@app.errorhandler(500)
def server_error(error):
    return render_template("error.html"), 500

if __name__ == "__main__":
    app.run(debug=True)

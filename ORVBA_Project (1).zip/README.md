# ORVBA — On-Road Vehicle Breakdown Assistance

A student-project starter application with:
- **Frontend:** HTML, CSS, JavaScript, Bootstrap icons via CDN
- **Backend:** Python Flask REST-style routes
- **Database:** MySQL
- **External service:** OpenStreetMap + Leaflet maps (no API key required)
- **Roles:** user, mechanic, admin
- **Core flow:** register/login, submit breakdown request with location, view requests, mechanic list, admin dashboard.

## Requirements
- Python 3.10+
- MySQL Server
- Browser with internet access for map tiles/CDN

## Setup
1. Create a MySQL database and tables:
   ```bash
   mysql -u root -p < database/orvba.sql
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```
3. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
4. Set environment variables (recommended):
   ```bash
   # Windows PowerShell
   $env:DB_HOST="localhost"
   $env:DB_USER="root"
   $env:DB_PASSWORD="your_mysql_password"
   $env:DB_NAME="orvba"
   $env:SECRET_KEY="change-this-to-a-long-random-secret"
   ```
   On macOS/Linux use `export DB_HOST=...` etc.
5. Start:
   ```bash
   python app.py
   ```
6. Open http://127.0.0.1:5000

## Demo admin account
Register a normal account first, then promote it in MySQL:
```sql
UPDATE users SET role='admin' WHERE email='your-email@example.com';
```
For a mechanic account:
```sql
UPDATE users SET role='mechanic' WHERE email='mechanic-email@example.com';
```
Then log out and log back in.

## External map service
The frontend uses Leaflet and OpenStreetMap tiles. The user's browser geolocation is requested only after pressing **Use my location**. A location is shared with the app only when the user submits the request. For production, review OpenStreetMap tile usage policies and add a privacy notice.

## Important limitations
This is an educational starter, not a production-ready roadside dispatch system. Add email/SMS notifications, rate limiting, CSRF protection, HTTPS, stronger admin provisioning, audit logs, and production hosting before real use. Never commit database passwords or a real SECRET_KEY.
